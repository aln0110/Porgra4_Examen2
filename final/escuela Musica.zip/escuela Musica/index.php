
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Index</title>
</head>
<body>
    <h1>This is the index page for the project of esceula de musica</h1>
    
    <p>These are the links for the pages inside the project</p>
    

    
    <b>Link to the escuela page: </b>
    <a href="view/escuelaView.php">Escuela de musica</a> <br>

    <b>Link to the junta page: </b>
    <a href="view/juntaView.php">Junta</a> <br>

    <b>Link to the partitura page: </b>
    <a href="view/partiruaView.php">Partitura</a> <br>

    <b>Link to the ciclo page: </b>
    <a href="view/cicloView.php">Ciclo</a><br>

    <b>Link to the instrumento page: </b>
    <a href="view/instrumentoView.php">Instrumento</a><br>

    <b>Link to instrumentos(This create the type of instrument)</b>
    <a href="view/instrumentosView.php">Instrumentos</a><br>

    <b>Link to categoria</b>
    <a href="view/categoriaView.php">Categoria</a><br>

    <b>Link to the estudiante page: </b>
    <a href="view/estudianteView.php">Estudiante</a> <br>

    <b>Link to the curso page</b>
    <a href="view/cursoView.php">Curso</a><br>

    <b>Link to the profesor page</b>
    <a href="view/profesorView.php">Profesor</a><br>

    <b>Link to the matricula page</b>
    <a href="view/matriculaView.php">Matricula</a><br>

    <b>Link to nota page</b>
    <a href="view/notaView.php">Nota</a><br>\

    <b>Link to the historial page</b>
    <a href="view/historialView.php">Historial</a><br>

    <b>Link to the prueba page</b>
    <a href="view/prueba.php">Prueba</a><br>




    
    
</body>
</html>