<?php
echo "STFU";
?>