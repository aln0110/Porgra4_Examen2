<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nota</title>
</head>
<body>

<form action="notaEdit.php" method="get">
    <label for="">Digite la cedula de un estudiante</label><br>
    <input type="text" name="cedulaEstudiante" id="cedulaEstudiante" required><br>
    <input type="submit" value="Buscar">
</form>

<a href="/index.php">Volver</a>
</body>
</html>